const express = require('express');
const mongoose = require('mongoose');
const eventsRouter = require('./routes/events');

const app = express();

app.use(express.json());

app.use('/events', eventsRouter);

mongoose.connect('mongodb://localhost/eventplanner', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
  app.listen(3000, () => {
    console.log('Server running on port 3000');
  });
}).catch(err => {
  console.error('Error connecting to MongoDB', err);
});
