const authMiddleware = (req, res, next) => {
  // Check if user is authenticated
  // If authenticated, call next()
  // If not, return res.status(401).send('Unauthorized');
};

module.exports = { authMiddleware };
