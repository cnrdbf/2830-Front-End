import React, { useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

const localizer = momentLocalizer(moment);

function EventList() {
  const [events, setEvents] = useState([]);

  const handleSelectSlot = async ({ start, end }) => {
    const title = window.prompt('Enter Event Title:');
    if (title) {
      const newEvent = { start, end, title };
      setEvents([...events, newEvent]);
      try {
        const response = await fetch('/events', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(newEvent),
        });
        if (!response.ok) {
          throw new Error('Failed to create event');
        }
      } catch (error) {
        console.error('Error:', error);
      }
    }
  };

  return (
    <div>
      <h2>Create Events on your Calendar!</h2>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        selectable
        onSelectSlot={handleSelectSlot}
        style={{ height: 500 }}
      />
    </div>
  );
}

export default EventList;
